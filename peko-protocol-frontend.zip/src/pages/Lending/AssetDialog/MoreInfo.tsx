export default function MoreInfo() {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-gray-500">Reserve Address</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-gray-500">Reserve Address</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-gray-500">Reserve Address</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-gray-500">Reserve Address</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-gray-500">Reserve Address</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-gray-500">Reserve Address</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-gray-500">Reserve Address</span>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-gray-500">Reserve Address</span>
      </div>
    </div>
  )
}