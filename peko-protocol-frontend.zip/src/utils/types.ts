export type TBuySellTabValue = "buy" | "sell";
export type TAssetSymbol = "eth" | "usdc";
